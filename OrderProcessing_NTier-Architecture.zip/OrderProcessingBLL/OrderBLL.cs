﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OrderProcessingBLL;
using OrderProcessing_DTO;
using OrderProcessingDAL;
using productProcessingDAL;

namespace OrderProcessingBLL
{
    public class OrderBLL:IOrderBLL
    {

        private readonly IOrders _orders;
        private readonly ICustomers _customers;
        private readonly IProducts _products;
        private readonly IOrderItems _items;
        public OrderBLL(IOrders orders, ICustomers customers,IProducts products,IOrderItems items)
        {
            _orders = orders;
            _customers = customers;
            _products = products;
            _items = items;
        }
        public void OrderCreation(Orders order)
        {
           
            Customers customer = _customers.GetCustomerById(order.customerId);
            if (customer == null)
            {
                throw new Exception("Customer not found");
            }
            decimal _totalAmount = 0.0m;
            foreach (var orderItem in order.orderItems)
            {
                Products product = _products.SearchById(orderItem.productId);
                if (product == null)
                {
                    throw new Exception("Product not found");
                }
                else if (product.quantity < orderItem.quantity)
                {
                    throw new Exception("Insufficient Stock");
                }
                orderItem.price = product.price * orderItem.quantity;
                _totalAmount += orderItem.price;
            }
            order.totalAmount = _totalAmount;
            _orders.AddOrder(order);
        }

        public List<Orders> getAllOrders()
        {
            return _orders.GetOrders();
        }


        public Orders SearchOrderById(int id)
        {
            Orders order=_orders.SearchById(id);
            if(order==null)
            {
                throw new Exception("Order with such Id doesn't exist!");
            }
            return order;
        }

        public OrderItems SearchItemById(int id)
        {
            return _items.SearchById(id);
        }

        public void UpdateOrder(Orders order)
        {
            decimal totAmount = 0;
            Orders newOrder=_orders.SearchOrderById(order.id);
            if (newOrder == null)
            {
                throw new Exception("Order with such Id doesn't exist!");
            }

            foreach (var item in order.orderItems)
            {
                totAmount += (item.price * item.quantity);
            }

            order.totalAmount = totAmount;
            _orders.UpdateOrder(order);
        }

        public void deleteOrder(int id)
        {
            Orders newOrder = _orders.SearchOrderById(id);
            if (newOrder == null)
            {
                throw new Exception("Order with such Id doesn't exist!");
            }
            _orders.DeleteOrderById(id);
        }

        public List<Orders> SearchOrderByName(string customerName)
        {
            List<Orders> order= _orders.SearchByName(customerName);
            return order;

        }


        public List<Orders> SearchOrdersByDateRange(string startDate,string endDate)
        {
            List<Orders> order=_orders.SearchByDateRange(startDate, endDate);
            return order;
        }



    }
}