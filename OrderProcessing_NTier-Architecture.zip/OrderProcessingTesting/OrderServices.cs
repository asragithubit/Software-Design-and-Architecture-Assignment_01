﻿using Moq;
using OrderProcessingBLL;
using OrderProcessingDAL;
using OrderProcessing_DTO;
using Castle.Core.Resource;

namespace OrderProcessingTests
{
    public class OrderCreationTests
    {
        private readonly Mock<IOrders> _orderRepositoryMock;
        private readonly Mock<ICustomers> _customerRepositoryMock;
        private readonly Mock<IProducts> _productRepositoryMock;
        private readonly Mock<IOrderItems> _orderItemsRepositoryMock;
        private readonly OrderBLL _orderService;

        public OrderCreationTests()
        {
            _orderRepositoryMock = new Mock<IOrders>();
            _customerRepositoryMock = new Mock<ICustomers>();
            _productRepositoryMock = new Mock<IProducts>();
            _orderItemsRepositoryMock= new Mock<IOrderItems>();
            _orderService = new OrderBLL(_orderRepositoryMock.Object, _customerRepositoryMock.Object, _productRepositoryMock.Object,_orderItemsRepositoryMock.Object);
        }

        [Test]
        public void CreateOrder_InvalidCustomer_ShouldThrowException()
        {
            // Arrange
            var order = new Orders { customerId = 999, orderItems = new List<OrderItems> { new OrderItems { productId = 1, quantity = 1 } } };
            _customerRepositoryMock.Setup(repo => repo.GetCustomerById(It.IsAny<int>())).Returns((Customers)null);

            // Act & Assert
            Assert.Throws<Exception>(() => _orderService.OrderCreation(order));
        }

        [Test]
        public void CreateOrder_InsufficientStock_ShouldThrowException()
        {
            // Arrange
            var customer = new Customers { id = 1, name = "John Doe" };
            var product = new Products { id = 1, name = "Product 1", quantity = 0, price = 100 };
            var order = new Orders { customerId = 1, orderItems = new List<OrderItems> { new OrderItems { productId = 1, quantity = 1 } } };
            _customerRepositoryMock.Setup(repo => repo.GetCustomerById(It.IsAny<int>())).Returns(customer);
            _productRepositoryMock.Setup(repo => repo.SearchById(It.IsAny<int>())).Returns(product);

            // Act & Assert
            Assert.Throws<Exception>(() => _orderService.OrderCreation(order));
        }


        [Test]
        public void UpdateOrder_NonExistentOrder_ShouldThrowException()
        {
            // Arrange
            var order = new Orders { id = 999, orderItems = new List<OrderItems> { new OrderItems { productId = 1, quantity = 1 } } };
            _orderRepositoryMock.Setup(repo => repo.SearchOrderById(It.IsAny<int>())).Returns((Orders)null);

            // Act & Assert
            Assert.Throws<Exception>(() => _orderService.UpdateOrder(order));
        }

        [Test]
        public void DeleteOrder_NonExistentOrder_ShouldThrowException()
        {
            // Arrange
            _orderRepositoryMock.Setup(repo => repo.SearchOrderById(It.IsAny<int>())).Returns((Orders)null);

            // Act & Assert
            Assert.Throws<Exception>(() => _orderService.deleteOrder(999));
        }


        [Test]
        public void SearchOrderByName_ValidCustomerName_ShouldReturnOrders()
        {
            // Arrange
            var orders = new List<Orders>
        {
            new Orders { id = 1, customerId = 1, totalAmount = 100, orderItems = new List<OrderItems>() },
            new Orders { id = 2, customerId = 2, totalAmount = 200, orderItems = new List<OrderItems>() }
        };
            _orderRepositoryMock.Setup(repo => repo.SearchByName("John Doe")).Returns(orders);

            // Act
            var result = _orderService.SearchOrderByName("John Doe");

            // Assert
            Assert.AreEqual(2, result.Count);
            
        }

    }
}