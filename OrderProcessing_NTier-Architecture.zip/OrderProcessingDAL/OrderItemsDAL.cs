﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Dapper.SqlMapper;
using OrderProcessing_DTO;

namespace OrderProcessingDAL
{
    public class OrderItemsDAL:IOrderItems
    {
        //private IDapperDAL<OrderItems> _OrderItems;
        private readonly string tableName = "OrderItems";
        private string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Assignment03;Integrated Security=True;";
        //OrderItemsDAL(IDapperDAL<OrderItems> OrderItems, string connectionString)
        //{
        //    _OrderItems = OrderItems;
        //    _OrderItems.setConnectionString(connectionString);
        //}
        public void AddOrderItems(OrderItems items)
        {
            var properties = typeof(OrderItems).GetProperties().Where(p => p.Name != "Id");
            var columnNames = string.Join(",", properties.Select(x => x.Name));
            var parameterNames = string.Join(",", properties.Select(y => "@" + y.Name));
            string query = $"INSERT INTO OrderItems ({columnNames}) VALUES ({parameterNames})";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                conn.Execute(query, items);
            }
        }

        public List<OrderItems> GetOrderItems(int orderId)
        {
            try
            {
                string query = "SELECT * FROM OrderItems where orderId=@orderId ";


                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    return conn.Query<OrderItems>(query, new {orderId}).ToList();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{ex.GetType} says {ex.Message}");
                throw new Exception("No Data Found", ex);
            }
        }

        public List<OrderItems> GetOrderItems()
        {
            try
            {
                string query = $"SELECT * FROM OrderItems";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    return conn.Query<OrderItems>(query).ToList();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{ex.GetType} says {ex.Message}");
                throw new Exception("No Data Found", ex);
            }
        }
        public void UpdateOrderItems(OrderItems items)
        {
            try
            {

                var properties = typeof(OrderItems).GetProperties().Where(p => p.Name != "Id");
                var values = string.Join(",", properties.Select(y => y.Name + " = @" + y.Name));

                string query = $"UPDATE OrderItems SET {values} WHERE Id = @Id";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    conn.Execute(query, items);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public void DeleteOrderItemsById(int id)
        {
            try
            {

                string query = $"DELETE FROM OrderItems WHERE Id = @Id";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    conn.Execute(query, new { ID = id });
                }
            }
            catch (Exception ex)
            {
                throw new Exception("No Data Found", ex);
            }
        }
        public void DeleteOrderItemsByName(string name)
        {
            try
            {

                string query = $"DELETE FROM OrderItems WHERE name = @name";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    conn.Execute(query, new { NAME = name });
                }
            }
            catch (Exception ex)
            {
                throw new Exception("No Data Found", ex);
            }
        }

        public OrderItems SearchById(int id)
        {
            try
            {
                string query = $"SELECT * FROM OrderItems WHERE Id = @Id";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    return conn.QuerySingleOrDefault<OrderItems>(query, new { ID = id });
                }
            }
            catch (Exception ex)
            {
                throw new Exception("No Data Found", ex);
            }
        }

        public List<OrderItems> SearchByOrderId(int id)
        {
            try
            {
                string query = $"SELECT * FROM OrderItems WHERE orderId = @orderId";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    return conn.Query<OrderItems>(query, new { orderId = id }).ToList();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("No Data Found", ex);
            }
        }

        public OrderItems SearchByName(string name)
        {
            try
            {

                string query = $"SELECT * FROM OrderItems WHERE name = @name";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    return conn.QuerySingleOrDefault<OrderItems>(query, new { name = name });
                }

            }
            catch (Exception ex)
            {
                throw new Exception("No Data Found", ex);
            }
        }

    }
}