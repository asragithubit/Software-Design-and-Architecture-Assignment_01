﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Dapper.SqlMapper;
using OrderProcessing_DTO;


namespace OrderProcessingDAL
{
    public class CustomersDAL:ICustomers
    {

        private readonly string tableName = "Customers";
        private string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Assignment03;Integrated Security=True;";
        //private readonly ICustomers _customers;
        //public CustomersDAL(ICustomers customers)
        //{
        //    _customers = customers;
        //}
        public void AddCustomer(Customers customer)
        {
            try
            {
                var properties = typeof(Customers).GetProperties().Where(p => p.Name != "id");
                var columnNames = string.Join(",", properties.Select(x => x.Name));
                var parameterNames = string.Join(",", properties.Select(y => "@" + y.Name));

                string query = $"INSERT INTO {tableName} ({columnNames}) VALUES ({parameterNames})";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    conn.Execute(query, customer);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: "+ex.Message);
            }

        }

        public List<Customers> GetCustomers()
        {
            try
            {
                string query = $"SELECT * FROM Customers";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    return conn.Query<Customers>(query).ToList();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.Message);
                throw new Exception("No Data Found", ex);
            }

        }
        public void UpdateCustomers(Customers customer)
        {
            try
            {

                var properties = typeof(Customers).GetProperties().Where(p => p.Name != "id");
                var values = string.Join(",", properties.Select(y => y.Name + " = @" + y.Name));

                string query = $"UPDATE Customers SET {values} WHERE id = @ID";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    conn.Execute(query, customer);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.Message);
            }
        }

        public void DeleteCustomerById(int id)
        {
            try
            {

                string query = $"DELETE FROM Customers WHERE id = @ID";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    conn.Execute(query, new { ID = id });
                }
            }
            catch (Exception ex)
            {
                throw new Exception("No Data Found", ex);
            }

        }

        public Customers GetCustomerById(int id)
        {
            try
            {
                string query = $"SELECT * FROM Customers WHERE id = @ID";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    return conn.QuerySingleOrDefault<Customers>(query, new { ID = id });
                }
            }
            catch (Exception ex)
            {
                throw new Exception("No Data Found", ex);
            }
        }

        public Customers GetCustomerByName(string name)
        {
            try
            {
                string query = $"SELECT * FROM Customers WHERE name = @Name";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    return conn.QuerySingleOrDefault<Customers>(query, new { Name = name });
                }
            }
            catch (Exception ex)
            {
                throw new Exception("No Data Found", ex);
            }
        }
    }
}