﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Dapper.SqlMapper;
using OrderProcessing_DTO;

namespace productProcessingDAL
{
    public class ProductsDAL:IProducts
    {
        //private IDapperDAL<Products> _Products;
        private readonly string tableName = "Products";
        private string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Assignment03;Integrated Security=True;";
        //ProductsDAL(IDapperDAL<Products> Products, string connectionString)
        //{
        //    _Products = Products;
        //    _Products.setConnectionString(connectionString);
        //}
        public void AddProduct(Products product)
        {
            var properties = typeof(Products).GetProperties().Where(p => p.Name != "id");
            var columnNames = string.Join(",", properties.Select(x => x.Name));
            var parameterNames = string.Join(",", properties.Select(y => "@" + y.Name));
            string query = $"INSERT INTO Products ({columnNames}) VALUES ({parameterNames})";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                conn.Execute(query, product);
            }
        }

        public List<Products> GetProducts()
        {
            try
            {
                string query = $"SELECT * FROM Products";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    return conn.Query<Products>(query).ToList();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{ex.GetType} says {ex.Message}");
                throw new Exception("No Data Found", ex);
            }
        }
        public void UpdateProduct(Products product)
        {
            try
            {

                var properties = typeof(Products).GetProperties().Where(p => p.Name != "id");
                var values = string.Join(",", properties.Select(y => y.Name + " = @" + y.Name));

                string query = $"UPDATE Products SET {values} WHERE ID = @ID";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    conn.Execute(query, product);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public void DeleteProductById(int id)
        {
            try
            {

                string query = $"DELETE FROM Products WHERE id = @ID";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    conn.Execute(query, new { ID = id });
                }
            }
            catch (Exception ex)
            {
                throw new Exception("No Data Found", ex);
            }
        }
        public void DeleteProductByName(string name)
        {
            try
            {

                string query = $"DELETE FROM Products WHERE name = @NAME";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    conn.Execute(query, new { NAME = name });
                }
            }
            catch (Exception ex)
            {
                throw new Exception("No Data Found", ex);
            }
        }

        public Products SearchById(int id)
        {
            try
            {
                string query = $"SELECT * FROM Products WHERE id = @ID";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    return conn.QuerySingleOrDefault<Products>(query, new { ID = id });
                }
            }
            catch (Exception ex)
            {
                throw new Exception("No Data Found", ex);
            }
        }

        public Products SearchByName(string name)
        {
            try
            {

                string query = $"SELECT * FROM Products WHERE name = @NAME";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    return conn.QuerySingleOrDefault<Products>(query, new { Name = name });
                }

            }
            catch (Exception ex)
            {
                throw new Exception("No Data Found", ex);
            }
        }

    }
}