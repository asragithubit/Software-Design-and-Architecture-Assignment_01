﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Dapper.SqlMapper;
using OrderProcessing_DTO;
using System.Runtime.InteropServices;


namespace OrderProcessingDAL
{
    public class OrdersDAL:IOrders
    {
        //private IDapperDAL<Orders> _Orders;
        private readonly IOrderItems _items;
        private readonly IProducts _products;
        private readonly ICustomers _customers;

        private readonly string tableName = "Orders";
        private string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Assignment03;Integrated Security=True;";

        public OrdersDAL(IOrderItems items, IProducts products, ICustomers customers)
        {
            _items = items;
            _products = products;
            _customers = customers;
        }

        //OrdersDAL(IDapperDAL<Orders> Orders, string connectionString)
        //{
        //    _Orders = Orders;
        //    _Orders.setConnectionString(connectionString);
        //}
        public void AddOrder(Orders order)
        {
            var properties = typeof(Orders).GetProperties().Where(p => p.Name != "id" && p.Name != "orderItems");
            var columnNames = string.Join(",", properties.Select(x => x.Name));
            var parameterNames = string.Join(",", properties.Select(y => "@" + y.Name));
            string query = $"INSERT INTO Orders ({columnNames}) VALUES ({parameterNames})";



            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                conn.Execute(query, order);
            }

            int Id = GetOrderId(order);
            foreach (var orderItem in order.orderItems)
            {
                orderItem.orderId = Id;
                _items.AddOrderItems(orderItem);
            }
        }

        public List<Orders> GetOrders()
        {
            try
            {
                string query = $"SELECT * FROM Orders";
                List<OrderItems> items = _items.GetOrderItems();
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    List<Orders> orders = conn.Query<Orders>(query).ToList();

                    foreach (var order in orders)
                    {
                        order.orderItems = items.Where(item => item.orderId == order.id).ToList();
                    }

                    return orders;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{ex.GetType} says {ex.Message}");
                throw new Exception("No Data Found", ex);
            }
        }
        public void UpdateOrder(Orders order)
        {
            try
            {
                var properties = typeof(Orders).GetProperties().Where(p => p.Name != "id" && p.Name != "orderItems");
                var values = string.Join(",", properties.Select(y => y.Name + " = @" + y.Name));
                string query = $"UPDATE Orders SET {values} WHERE id = @id";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    conn.Execute(query, order);
                }
                foreach (var orderItem in order.orderItems)
                {

                    orderItem.orderId = order.id;
                    _items.UpdateOrderItems(orderItem);
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public void DeleteOrderById(int id)
        {
            try
            {

                string query = $"DELETE FROM Orders WHERE id = @id";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    conn.Execute(query, new { id = id });
                }
            }
            catch (Exception ex)
            {
                throw new Exception("No Data Found", ex);
            }
        }
        public void DeleteOrderByName(string name)
        {
            try
            {

                string query = $"DELETE FROM Orders WHERE name = @name";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    conn.Execute(query, new { name = name });
                }
            }
            catch (Exception ex)
            {
                throw new Exception("No Data Found", ex);
            }
        }

        public Orders SearchOrderById(int id)
        {
            try
            {
                List<OrderItems> item = _items.SearchByOrderId(id);
                string query = $"SELECT * FROM Orders WHERE id = @id";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    Orders order = conn.QuerySingleOrDefault<Orders>(query, new { id = id });
                    if (order != null)
                    {
                        order.orderItems = item;
                    }
                    return order;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("No Data Found", ex);
            }
        }

        public Orders SearchById(int id)
        {
            try
            {
                List<OrderItems> item = _items.SearchByOrderId(id);
                string query = $"SELECT * FROM Orders WHERE id = @id";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    Orders order = conn.QuerySingleOrDefault<Orders>(query, new { id = id });
                    if (order != null)
                    {
                        order.orderItems = item;
                    }
                    return order;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("No Data Found", ex);
            }
        }

        public int GetOrderId(Orders order)
        {

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT id FROM Orders WHERE CustomerId = @customerId AND orderDate = @orderDate and totalAmount = @totalAmount";
                return conn.QueryFirstOrDefault<int>(query, new { order.customerId, order.orderDate, order.totalAmount });
            }
        }

        public List<Orders> SearchByName(string name)
        {

            string query = "Select * from Orders o join Customers c on o.customerId=c.id where c.name like @name";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                var orders = conn.Query<Orders>(query, new {name = "%" + name + "%" }).ToList();
                foreach (var order in orders)
                {
                    order.orderItems = _items.GetOrderItems(order.id);
                }
                return orders;
            }

        }
        public List<Orders> SearchByDateRange(string startDate,string endDate)
        {

            string query = "Select * from Orders where orderDate between @startDate and @endDate";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                var orders = conn.Query<Orders>(query, new { startDate=startDate,endDate=endDate }).ToList();
                foreach (var order in orders)
                {
                    order.orderItems = _items.GetOrderItems(order.id);
                }
                return orders;
            }

        }

    }
}