﻿using System.Numerics;
using OrderProcessingBLL;
using OrderProcessing_DTO;
using OrderProcessingDAL;

namespace OrderProcessing_PL
{
    public class OrderProcessingPL
    {
        private readonly IOrderBLL _orderbll;
        public OrderProcessingPL(IOrderBLL orderbll)
        {
            _orderbll = orderbll;
        }
        public void listAllOrders()
        {
            ////List<OrderItems> orderItems = new List<OrderItems>()
            //{
            //    new OrderItems() {Price=1,ProductId=1,quantity=3},
            //    new OrderItems() {Price=3,ProductId=2,quantity=5},
            //    new OrderItems() {Price=4,ProductId=3,quantity=6},
            //};


            //{
            //    CustomerId = 3,
            //    OrderDate = (new DateOnly(DateTime.Now.Year, 12, 1)).ToString(),
            //    OrderItems = orderItems
            //};

            Console.WriteLine("\n\n\t\t================Listing all Orders===============\n");
            List<Orders> orders = _orderbll.getAllOrders();
            int orderNumber = 1;
            int itemNumber;

            foreach (Orders order in orders)
            {
                Console.WriteLine($"\nOrder {orderNumber}\n");
                Console.WriteLine($"Order Id: {order.id}");
                Console.WriteLine($"Customer's Id: {order.customerId}");
                Console.WriteLine($"Order Date: {order.orderDate}");
                itemNumber = 1;
                orderNumber++;
                if (order.orderItems != null)
                {
                    Console.WriteLine("\n========================\n");
                    Console.WriteLine($"\nOrder Items Within Order {orderNumber}\n");
                    foreach (var orderItem in order.orderItems)
                    {
                        Console.WriteLine($"Order Item {itemNumber}\n");
                        Console.WriteLine($" Id: {orderItem.Id}");
                        Console.WriteLine($"Order Id: {orderItem.orderId}");
                        Console.WriteLine($"Product Id: {orderItem.productId}");
                        Console.WriteLine($"Quantity : {orderItem.quantity}");
                        Console.WriteLine($"Price : {orderItem.price}");
                        itemNumber++;
                    }
                    Console.WriteLine("\n========================\n");
                }
                else
                {
                    Console.WriteLine("No order items found for this order.");
                }
            }
            Console.WriteLine("\n\n\t\t===============================================\n");

        }

        public void addNewOrder()
        {
            Console.WriteLine("\n\n\t\t================Order Creation===============\n");
            Console.Write("Customer Id: ");
            int customerId = int.Parse(Console.ReadLine());


            List<OrderItems> items = new List<OrderItems>();
            while (true)
            {
                Console.Write("Product Id: ");
                int productId = int.Parse(Console.ReadLine());
                Console.Write("Product Quantity: ");
                int quantity = int.Parse(Console.ReadLine());
                items.Add(new OrderItems { productId = productId, quantity = quantity });
                Console.Write("Want to add more products? [Y/N]: ");
                string ans = Console.ReadLine();
                if (ans == "y" || ans == "Y")
                    continue;
                else
                    break;
            }

            Orders order = new Orders()
            {
                customerId = customerId,
                orderDate = (DateTime.Now.Year, 12, 1).ToString(),
                orderItems = items
            };

            //ICustomersDAL customerDal;
            _orderbll.OrderCreation(order);
            Console.WriteLine("\n\n\t\t===============================================\n");


        }

        public void updateAnExistingOrder()
        {

            Console.WriteLine("\n\n\t\t================Update Order===============\n");
            Console.Write("Id of Order: ");
            int id=int.Parse(Console.ReadLine());
            if(id<0)
            {
                Console.WriteLine("Invalid Order Id");
                return;
            }
            else
            {
                Orders order= _orderbll.SearchOrderById(id);
                if(order!=null)
                {
                    if (order.orderItems != null)
                    {
                        foreach (var item in order.orderItems)
                        {
                            Console.WriteLine($"Item Id: {item.Id}, Product Id: {item.productId}, Current Quantity: {item.quantity}, Price: {item.price}");
                        }

                        Console.Write("Item Id You Want to Update: ");
                        int itemId = int.Parse(Console.ReadLine());

                        OrderItems orderItem = order.orderItems.FirstOrDefault(oi => oi.Id == itemId);
                        if (orderItem != null)
                        {
                            Console.Write("Updated Quantity: ");
                            int newQuantity=int.Parse(Console.ReadLine());
                            if(newQuantity<0)
                            {
                                Console.WriteLine("Quantity Should be Valid i.e > 0");
                                return;
                            }
                            else
                            {
                                orderItem.quantity = newQuantity;
                                _orderbll.UpdateOrder(order);
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("Order Items Within Such Order Doesn't Exist!");
                        return;
                    }
                }
                else
                {
                    Console.WriteLine("Order With Such Id doesn't exist!");
                }

            }
            Console.WriteLine("\n\n\t\t===============================================\n");

        }

        public void deleteAnOrder()
        {

            Console.WriteLine("\n\n\t\t================Delete Order===============\n");
            Console.Write("Id of Order: ");
            int id = int.Parse(Console.ReadLine());
            if (id < 0)
            {
                Console.WriteLine("Invalid Order Id!");
                return;
            }
            else
            {
                Orders order = _orderbll.SearchOrderById(id);
                if (order != null)
                {
                    _orderbll.deleteOrder(id);
                }
                else
                {
                    Console.WriteLine($"Order with OrderId {id} doesn't exist!");
                }
            }

            Console.WriteLine("\n\n\t\t===============================================\n");

        }

        public void searchAnOrder()
        {

            Console.WriteLine("\n\n\t\t================Search Order===============\n");
            Console.WriteLine("1. Search by Order ID");
            Console.WriteLine("2. Search by Customer Name");
            Console.WriteLine("3. Search by Date Range");
            Console.Write("Your Choice: ");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    SearchById();
                    break;
                case 2:
                    SearchByCustomerName();
                    break;
                case 3:
                    SearchByDateRange();
                    break;
                default:
                    Console.WriteLine("Invalid choice.");
                    break;
            }
            Console.WriteLine("\n\n\t\t===============================================\n");

        }

        private void SearchById()
        {

            Console.WriteLine("\n\n\t\t======Search Order By Id=====\n");
            Console.Write("Order ID: ");
            int id = int.Parse(Console.ReadLine());

            Orders order = _orderbll.SearchOrderById(id);
            if (order != null)
            {
                DisplayOrder(order);
            }
            else
            {
                Console.WriteLine("Order not found.");
            }
            Console.WriteLine("\n\n\t\t=========================\n");

        }

        private void SearchByCustomerName()
        {
            Console.WriteLine("\n\n\t\t======Search Order By Name=====\n");
            Console.Write("Customer Name: ");
            string customerName = Console.ReadLine();
            List<Orders> orders = _orderbll.SearchOrderByName(customerName);
            if (orders.Count > 0)
            {
                foreach (var order in orders)
                {
                    DisplayOrder(order);
                }
            }
            else
            {
                Console.WriteLine("No orders found for this customer.");
            }
            Console.WriteLine("\n\n\t\t=========================\n");

        }

        private void SearchByDateRange()
        {
            Console.WriteLine("\n\n\t\t======Search Order By Date Range=====\n");
            Console.Write("Enter Start Date (yyyy-mm-dd): ");
            string startDate = Console.ReadLine();

            //if (!DateTime.TryParse(Console.ReadLine(), out startDate))
            //{
            //    Console.WriteLine("Invalid start date format.");
            //    return;
            //}

            Console.Write("Enter End Date (yyyy-mm-dd): ");
            string endDate=Console.ReadLine();
            //if (!DateTime.TryParse(Console.ReadLine(), out endDate))
            //{
            //    Console.WriteLine("Invalid end date format.");
            //    return;
            //}

            //if (startDate > endDate)
            //{
            //    Console.WriteLine("Start date must be earlier than end date.");
            //    return;
            //}
            List<Orders> orders = _orderbll.SearchOrdersByDateRange(startDate, endDate);
            if (orders.Count > 0)
            {
                foreach (var order in orders)
                {
                    DisplayOrder(order);
                }
            }
            else
            {
                Console.WriteLine("No orders found in this date range.");
            }
            Console.WriteLine("\n\n\t\t=========================\n");

        }

        private void DisplayOrder(Orders order)
        {
            Console.WriteLine("\n\n\t\t======Dsiplaying Order=====\n");

            Console.WriteLine($"\nOrder ID: {order.id}");
            Console.WriteLine($"Customer ID: {order.customerId}");
            Console.WriteLine($"Order Date: {order.orderDate}");
            Console.WriteLine($"Total Amount: {order.totalAmount}");
            Console.WriteLine($"\nOrder Items\n");
            foreach (var item in order.orderItems)
            {
                Console.WriteLine($"  Item ID: {item.Id}, Product ID: {item.productId}, Quantity: {item.quantity}, Price: {item.price}");
            }
            Console.WriteLine("\n\n\t\t=========================\n");

        }

    }
}