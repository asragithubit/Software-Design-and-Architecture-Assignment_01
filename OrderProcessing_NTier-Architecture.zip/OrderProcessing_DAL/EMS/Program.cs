﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using OrderProcessing_DTO;
using OrderProcessing_PL;
using OrderProcessingDAL;
using productProcessingDAL;
using Microsoft.Extensions.DependencyInjection;
using OrderProcessingBLL;


namespace OrderProcessing
{
    class Program
    {

        static void Main(string[] args)
        {

            var ServiceCollection = new ServiceCollection();
            ConfigureServices(ServiceCollection);
            var serviceProvider= ServiceCollection.BuildServiceProvider();
            var order=serviceProvider.GetService<OrderProcessingPL> (); 

            while (true)
            {
                Console.WriteLine("Order Processing System");
                Console.WriteLine("1. List all orders");
                Console.WriteLine("2. Add a new order");
                Console.WriteLine("3. Update an existing order");
                Console.WriteLine("4. Delete an order");
                Console.WriteLine("5. Search for orders");
                Console.WriteLine("6. Exit");
                Console.Write("Choose an option: ");

                int choice = int.Parse(Console.ReadLine());
               
                switch (choice)
                {
                    case 1:

                        order.listAllOrders();
                        break;

                    case 2:

                        order.addNewOrder();
                        break;

                    case 3:

                        order.updateAnExistingOrder();
                        break;

                    case 4:

                        order.deleteAnOrder();
                        break;

                    case 5:

                        order.searchAnOrder();
                        break;

                    case 6:
                        return;

                    default:
                        Console.WriteLine("Invalid choice.");
                        break;

                }
            }
        }
        private static void ConfigureServices(IServiceCollection services)
        {

            services.AddTransient<CustomersDAL>();
            services.AddTransient<OrdersDAL>();
            services.AddTransient<OrderItemsDAL>();
            services.AddTransient<ProductsDAL>();

            services.AddTransient<ICustomers, CustomersDAL>();
            services.AddTransient<IProducts, ProductsDAL>();
            services.AddTransient<IOrderItems, OrderItemsDAL>();
            services.AddTransient<IOrders, OrdersDAL>();
            services.AddTransient<IOrderBLL, OrderBLL>();


            services.AddTransient<OrderProcessingPL>();
            services.AddTransient<OrderBLL>();
            services.AddTransient<OrderItemsDAL>();

        }
    }
}