﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderProcessing_DTO
{
    internal class OrdersDTO
    {
        public int id { get; set; }
        public int customerId {  get; set; }
        public DateOnly orderDate { get; set; }
        public int totalAmount {  get; set; }

    }
}
