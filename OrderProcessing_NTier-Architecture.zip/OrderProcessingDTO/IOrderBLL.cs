﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderProcessing_DTO
{
    public interface IOrderBLL
    {
        public void OrderCreation(Orders order);
        public List<Orders> getAllOrders();
        public Orders SearchOrderById(int id);
        public OrderItems SearchItemById(int id);
        public void UpdateOrder(Orders order);
        public void deleteOrder(int id);
        public List<Orders> SearchOrderByName(string customerName);
        public List<Orders> SearchOrdersByDateRange(string startDate, string endDate);
    }
}
