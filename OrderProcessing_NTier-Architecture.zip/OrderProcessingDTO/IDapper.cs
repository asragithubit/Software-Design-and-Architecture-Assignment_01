﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Dapper.SqlMapper;

namespace OrderProcessing_DTO
{
    public interface IDapper<TEntity>
    {
        public void setConnectionString(string c);

        public void Add(TEntity entity, string tableName);
        public void Add(string columnNames, TEntity entity, string tableName);
        public List<TEntity> GetAll<TEntity>(string tableName) where TEntity : new();
        public List<TEntity> GetAll<TEntity>(string tableName, string comparisonParameter, string comparisonParameterValue) where TEntity : new();
        public void DeleteById(int id, string tableName);
        public TEntity FindById<TEntity>(int id, string tableName) where TEntity : new();
        public void Update(TEntity entity, string tableName);
    }
}