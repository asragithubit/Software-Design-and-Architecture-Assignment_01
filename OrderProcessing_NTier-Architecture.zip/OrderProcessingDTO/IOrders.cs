﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderProcessing_DTO
{
    public interface IOrders
    {

        public void AddOrder(Orders order);
        public Orders SearchOrderById(int id);

        public List<Orders> GetOrders();
        public void UpdateOrder(Orders order);

        public void DeleteOrderById(int id);
        public void DeleteOrderByName(string name);

        public Orders SearchById(int id);

        public int GetOrderId(Orders order);

        public List<Orders> SearchByName(string name);
        public List<Orders> SearchByDateRange(string startDate, string endDate);

    }
}
