﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderProcessing_DTO
{
    public interface IProducts
    {
        public void AddProduct(Products product);

        public List<Products> GetProducts();
        public void UpdateProduct(Products product);

        public void DeleteProductById(int id);
        public void DeleteProductByName(string name);

        public Products SearchById(int id);

        public Products SearchByName(string name);
    }
}
