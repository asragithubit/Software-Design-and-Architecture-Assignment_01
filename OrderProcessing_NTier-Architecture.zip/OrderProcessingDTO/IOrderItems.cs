﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderProcessing_DTO
{
    public interface IOrderItems
    {
      
        public void AddOrderItems(OrderItems items);

        public List<OrderItems> GetOrderItems(int orderId);

        public List<OrderItems> GetOrderItems();
        public void UpdateOrderItems(OrderItems items);

        public void DeleteOrderItemsById(int id);
        public void DeleteOrderItemsByName(string name);

        public OrderItems SearchById(int id);

        public List<OrderItems> SearchByOrderId(int id);

        public OrderItems SearchByName(string name);
    }
}
