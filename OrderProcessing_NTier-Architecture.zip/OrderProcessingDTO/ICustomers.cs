﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderProcessing_DTO
{
    public interface ICustomers
    {
        public void AddCustomer(Customers customer);

        public List<Customers> GetCustomers();
        public void UpdateCustomers(Customers customer);

        public void DeleteCustomerById(int id);

        public Customers GetCustomerById(int id);


        public Customers GetCustomerByName(string name);
    }
}
