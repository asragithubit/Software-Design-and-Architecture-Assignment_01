﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderProcessing_DTO
{
    public class Orders
    {
        public int id { get; set; }
        public int customerId { get; set; }
        public string orderDate { get; set; }
        public decimal totalAmount { get; set; }
        public List<OrderItems> orderItems { get; set; }

    }
}
